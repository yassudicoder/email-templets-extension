/* Canned Responses — ui/options/options.js
 * The template manager: two-pane list + rich-text editor over the shared
 * CR.store data layer. Create / edit / favorite / reorder / delete. */
(function () {
  "use strict";
  const { store, sanitize, model, theme, entitlements } = globalThis.CR;
  const canImages = () => !!(entitlements && entitlements.can("images"));

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  let selectedId = null;
  let query = "";
  let statusTimer = null;

  async function boot() {
    await store.init();
    $("#search").addEventListener("input", (e) => { query = e.target.value; renderList(); });
    $("#new").addEventListener("click", onNew);
    $("#hotkeyBtn").addEventListener("click", recordHotkey);
    $("#exportBtn").addEventListener("click", exportTemplates);
    $("#importBtn").addEventListener("click", () => $("#importFile").click());
    $("#importFile").addEventListener("change", onImportFile);
    $("#nudgeExport").addEventListener("click", exportTemplates);
    $("#nudgeDismiss").addEventListener("click", async () => { await store.updateSettings({ backupNudgeDismissedAt: Date.now() }); renderNudge(); });
    $("#nudgeWeekly").addEventListener("change", async (e) => { await store.updateSettings({ backupReminderWeekly: e.target.checked }); renderNudge(); });
    // External changes (e.g. inserting from a page never edits; but seeding /
    // other tabs do) — refresh the list without clobbering the open editor.
    store.subscribe(() => { renderList(); updateCount(); renderHotkey(); applyTheme(); renderNudge(); });
    // Theme toggle (Light / Dark / System)
    applyTheme();
    $("#themeSel").value = store.getSettings().theme || "system";
    $("#themeSel").addEventListener("change", async (e) => { await store.updateSettings({ theme: e.target.value }); applyTheme(); });
    try {
      window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
        if ((store.getSettings().theme || "system") === "system") applyTheme();
      });
    } catch (e) {}
    const settings = store.getSettings();
    // Opened from the "Copy email → Open editor" toast: start a fresh template
    // and focus the body so the user can paste straight away.
    const wasPaste = !!settings.pasteIntoNew;
    if (wasPaste) {
      await store.updateSettings({ pasteIntoNew: false });
      const rec = await store.create({ title: "Pasted email", body: "" });
      if (rec) selectedId = rec.id;
    }
    // Opened from the capture toast's "Edit": jump to that template.
    const focusId = settings.focusTemplateId;
    if (focusId && store.get(focusId)) { selectedId = focusId; store.updateSettings({ focusTemplateId: null }); }
    render();
    if (wasPaste && selectedId) { const b = $("#body"); if (b) b.focus(); }
    renderHotkey();
  }

  function applyTheme() { theme.applyToDocument((store.getSettings() && store.getSettings().theme) || "system"); }

  // ---- Hotkey preference ------------------------------------------------
  function renderHotkey() {
    const s = store.getSettings();
    const btn = $("#hotkeyBtn");
    if (btn && !btn.classList.contains("recording")) btn.textContent = (s && s.hotkey) || "Alt+A";
  }

  let recording = false;
  function recordHotkey() {
    if (recording) return;
    recording = true;
    const btn = $("#hotkeyBtn");
    btn.classList.add("recording");
    btn.textContent = "Press keys…";

    function cleanup() {
      recording = false;
      btn.classList.remove("recording");
      document.removeEventListener("keydown", onKey, true);
    }
    async function onKey(e) {
      if (["Control", "Alt", "Shift", "Meta", "OS"].includes(e.key)) return; // wait for the real key
      e.preventDefault(); e.stopPropagation();
      if (e.key === "Escape") { cleanup(); renderHotkey(); return; }
      const mods = [];
      if (e.ctrlKey) mods.push("Ctrl");
      if (e.altKey) mods.push("Alt");
      if (e.shiftKey) mods.push("Shift");
      if (e.metaKey) mods.push("Cmd");
      let key = null, m;
      if ((m = /^Key([A-Z])$/.exec(e.code))) key = m[1];
      else if ((m = /^Digit([0-9])$/.exec(e.code))) key = m[1];
      if (!mods.length || !key) { btn.textContent = "Use Alt/Ctrl + a letter"; return; }
      const hotkey = mods.concat(key).join("+");
      await store.updateSettings({ hotkey });   // content scripts pick this up live via onChanged
      cleanup();
      renderHotkey();
    }
    document.addEventListener("keydown", onKey, true);
  }

  function visibleTemplates() {
    let list = store.getAll();
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((t) =>
      (t.title + " " + sanitize.toPlainText(t.body)).toLowerCase().includes(q));
    return list;
  }

  function render() { renderList(); renderEditor(); updateCount(); renderNudge(); }

  // ---- Backup nudge (local-first data safety; never on install, dismissible) ----
  const WEEK_MS = 7 * 24 * 3600 * 1000;
  function shouldNudge() {
    const s = store.getSettings();
    const now = Date.now();
    if (now - (s.backupNudgeDismissedAt || 0) < WEEK_MS) return false;       // recently dismissed
    if (s.backupReminderWeekly) return store.count() > 0 && (now - (s.lastBackupAt || 0)) > WEEK_MS;
    return store.count() >= 12 && !(s.lastBackupAt);                          // enough to lose & never backed up
  }
  function renderNudge() {
    const el = $("#backupNudge");
    if (!el) return;
    const show = shouldNudge();
    el.hidden = !show;
    if (show) {
      $("#nudgeCount").textContent = store.count();
      $("#nudgeWeekly").checked = !!store.getSettings().backupReminderWeekly;
    }
  }

  function updateCount() {
    const n = store.getAll().length;
    const limit = store.templateLimit();
    const head = isFinite(limit) ? (n + " / " + limit) : String(n);
    $("#count").textContent = head + (n === 1 ? " template" : " templates");
  }

  // ---- List pane --------------------------------------------------------
  function renderList() {
    const list = visibleTemplates();
    const ul = $("#list");
    ul.innerHTML = "";
    if (!list.length) {
      const li = document.createElement("li");
      li.className = "empty";
      li.textContent = query ? "No matches." : "No templates yet — click + New.";
      ul.appendChild(li);
      return;
    }
    for (const t of list) {
      const li = document.createElement("li");
      li.className = "item" + (t.id === selectedId ? " sel" : "");
      li.draggable = !query;            // reorder only when not filtering
      li.dataset.id = t.id;
      li.innerHTML =
        `<button class="star ${t.favorite ? "on" : ""}" title="Favorite">${t.favorite ? "★" : "☆"}</button>
         <div class="itemmain"><div class="ititle"></div><div class="isnip"></div></div>`;
      li.querySelector(".ititle").textContent = t.title || "Untitled";
      li.querySelector(".isnip").textContent = sanitize.toPlainText(t.body).slice(0, 90) || "(empty)";
      li.addEventListener("click", (e) => {
        if (e.target.closest(".star")) return;
        selectedId = t.id; render();
      });
      li.querySelector(".star").addEventListener("click", async (e) => {
        e.stopPropagation();
        await store.update(t.id, { favorite: !t.favorite });
        renderList();
      });
      bindDrag(li);
      ul.appendChild(li);
    }
  }

  let dragId = null;
  function bindDrag(li) {
    li.addEventListener("dragstart", () => { dragId = li.dataset.id; li.classList.add("dragging"); });
    li.addEventListener("dragend", () => { li.classList.remove("dragging"); dragId = null; });
    li.addEventListener("dragover", (e) => e.preventDefault());
    li.addEventListener("drop", async (e) => {
      e.preventDefault();
      const targetId = li.dataset.id;
      if (!dragId || dragId === targetId) return;
      const ids = store.getAll().map((t) => t.id);
      const from = ids.indexOf(dragId);
      const to = ids.indexOf(targetId);
      if (from < 0 || to < 0) return;
      ids.splice(to, 0, ids.splice(from, 1)[0]);
      await store.reorder(ids);
      renderList();
    });
  }

  // ---- Editor pane ------------------------------------------------------
  function renderEditor() {
    const pane = $("#editorpane");
    const t = selectedId ? store.get(selectedId) : null;
    if (!t) {
      pane.innerHTML =
        `<div class="placeholder"><h2>No template selected</h2>
         <p>Pick a template on the left, or click <b>+ New</b> to create one.</p></div>`;
      return;
    }
    pane.innerHTML = `
      <div class="editor">
        <input id="title" class="title" placeholder="Template title">
        <div class="subrow">
          <label>Shortcut <input id="shortcut" class="shortcut" placeholder="e.g. resched"></label>
          <button id="fav" class="btn ghost">${t.favorite ? "★ Favorited" : "☆ Favorite"}</button>
        </div>
        <div class="toolbar">
          <select id="fontName" class="tsel" title="Font">
            <option value="">Font</option>
            <option value="Arial, sans-serif">Sans Serif</option>
            <option value="Georgia, serif">Serif</option>
            <option value="'Courier New', monospace">Monospace</option>
            <option value="'Times New Roman', serif">Times</option>
            <option value="Verdana, sans-serif">Verdana</option>
            <option value="'Trebuchet MS', sans-serif">Trebuchet</option>
          </select>
          <select id="fontSize" class="tsel" title="Size">
            <option value="">Size</option>
            <option value="2">Small</option>
            <option value="3">Normal</option>
            <option value="4">Large</option>
            <option value="6">Huge</option>
          </select>
          <button data-cmd="bold" title="Bold"><b>B</b></button>
          <button data-cmd="italic" title="Italic"><i>I</i></button>
          <button data-cmd="underline" title="Underline"><u>U</u></button>
          <button data-cmd="strikeThrough" title="Strikethrough"><s>S</s></button>
          <label class="colorbtn" title="Text colour"><b>A</b><input type="color" id="foreColor" value="#202124"></label>
          <label class="colorbtn" title="Highlight"><span class="hlmark">H</span><input type="color" id="hiliteColor" value="#fff34d"></label>
          <button data-cmd="insertUnorderedList" title="Bullet list">&bull;</button>
          <button data-cmd="insertOrderedList" title="Numbered list">1.</button>
          <button data-cmd="justifyLeft" title="Align left">&#9776;</button>
          <button data-cmd="justifyCenter" title="Centre">&#8801;</button>
          <button data-cmd="justifyRight" title="Align right">&#9776;</button>
          <button data-cmd="createLink" title="Insert link">&#128279;</button>
          <button data-cmd="removeFormat" title="Clear formatting">&#10006;</button>
          <span class="spacer"></span>
          <select id="varsel" class="varsel" title="Insert a variable">
            <option value="">+ Variable</option>
            <option value="first_name">{first_name}</option>
            <option value="last_name">{last_name}</option>
            <option value="company">{company}</option>
            <option value="my_name">{my_name}</option>
          </select>
        </div>
        <div id="body" class="body" contenteditable="true"></div>
        <div class="actions">
          <button id="del" class="btn danger">Delete</button>
          <div class="grow"></div>
          <span id="status" class="status"></span>
          <button id="save" class="btn primary">Save</button>
        </div>
      </div>`;
    $("#title").value = t.title || "";
    $("#shortcut").value = t.shortcut || "";
    $("#body").innerHTML = t.body || "";
    bindEditor(t.id);
  }

  function bindEditor(id) {
    const body = $("#body");
    try { document.execCommand("styleWithCSS", false, true); } catch (_) {} // colour/font -> style spans

    // Remember the editor selection so toolbar controls (selects, colour pickers)
    // that steal focus can still apply to what was selected.
    let savedRange = null;
    body.addEventListener("blur", () => {
      const s = window.getSelection();
      if (s && s.rangeCount && body.contains(s.anchorNode)) savedRange = s.getRangeAt(0).cloneRange();
    });
    function withSelection(fn) {
      body.focus();
      if (savedRange) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(savedRange); }
      fn();
    }

    $$(".toolbar button[data-cmd]").forEach((b) => {
      b.addEventListener("mousedown", (e) => e.preventDefault());   // keep the selection
      b.addEventListener("click", (e) => {
        e.preventDefault();
        body.focus();
        const cmd = b.dataset.cmd;
        if (cmd === "createLink") {
          const url = prompt("Link URL:", "https://");
          if (url) document.execCommand("createLink", false, url);
        } else {
          document.execCommand(cmd, false, null);
        }
      });
    });

    $("#fontName").addEventListener("change", (e) => {
      const v = e.target.value; e.target.selectedIndex = 0;
      if (v) withSelection(() => document.execCommand("fontName", false, v));
    });
    $("#fontSize").addEventListener("change", (e) => {
      const v = e.target.value; e.target.selectedIndex = 0;
      if (v) withSelection(() => document.execCommand("fontSize", false, v));
    });
    $("#foreColor").addEventListener("input", (e) =>
      withSelection(() => document.execCommand("foreColor", false, e.target.value)));
    $("#hiliteColor").addEventListener("input", (e) =>
      withSelection(() => {
        if (!document.execCommand("hiliteColor", false, e.target.value))
          document.execCommand("backColor", false, e.target.value);
      }));

    $("#varsel").addEventListener("change", (e) => {
      const v = e.target.value; e.target.value = "";
      if (!v) return;
      body.focus();
      document.execCommand("insertText", false, "{" + v + "}");
    });

    $("#fav").addEventListener("click", async () => {
      const cur = store.get(id);
      await store.update(id, { favorite: !(cur && cur.favorite) });
      render();
    });

    $("#del").addEventListener("click", async () => {
      if (!confirm("Delete this template?")) return;
      await store.softDelete(id);
      selectedId = null;
      render();
    });

    $("#save").addEventListener("click", () => save(id, false));
    // Autosave on blur so edits are never lost.
    [$("#title"), $("#shortcut"), body].forEach((el) =>
      el.addEventListener("blur", () => save(id, true)));
  }

  async function save(id, silent) {
    if (!store.get(id)) return;
    const title = $("#title").value.trim() || "Untitled";
    const shortcut = $("#shortcut").value.trim();
    const raw = $("#body").innerHTML;
    const allowImg = canImages();
    const body = sanitize.sanitize(raw, { images: allowImg });
    await store.update(id, { title, shortcut, body });
    if (!allowImg && sanitize.detectMedia(raw)) {
      $("#body").innerHTML = body;       // show what was actually saved (images removed)
      proNote("Saved (text & formatting). Images are a Pro feature — upgrade to keep them.");
    } else {
      setStatus(silent ? "Saved" : "Saved ✓");
    }
    renderList(); updateCount();     // refresh list; do NOT rebuild the editor (keeps focus)
  }

  function setStatus(msg) {
    const el = $("#status"); if (!el) return;
    el.classList.remove("upsell");
    el.textContent = msg;
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { if ($("#status")) $("#status").textContent = ""; }, 1600);
  }
  function proNote(msg) {
    const el = $("#status"); if (!el) return;
    el.classList.add("upsell");
    el.textContent = msg;
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { if ($("#status")) { $("#status").textContent = ""; $("#status").classList.remove("upsell"); } }, 6000);
  }

  async function onNew() {
    const rec = await store.create({ title: "Untitled", body: "" });
    if (!rec) { alert("You've reached the " + store.templateLimit() + "-template limit on the free plan. Delete one to add more."); return; }
    selectedId = rec.id;
    query = ""; $("#search").value = "";
    render();
    const titleEl = $("#title");
    if (titleEl) { titleEl.focus(); titleEl.select(); }
  }

  // ---- Export / Import --------------------------------------------------
  function exportTemplates() {
    const data = {
      app: "canned-responses",
      version: model.SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      templates: store.getAll().map((t) => ({
        title: t.title, body: t.body, shortcut: t.shortcut, tags: t.tags, favorite: t.favorite
      }))
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "canned-responses.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    store.updateSettings({ lastBackupAt: Date.now() });   // backed up -> stops the nudge
    renderNudge();
  }

  function onImportFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const parsed = JSON.parse(reader.result);
        const list = Array.isArray(parsed) ? parsed : (parsed && parsed.templates);
        if (!Array.isArray(list)) throw new Error("no templates array");
        const base = Date.now();
        // Import as NEW records (fresh UUIDs) so a friend's file adds to — never
        // overwrites — your library. Bodies are sanitized (untrusted file).
        const recs = list
          .filter((t) => t && (t.title || t.body))
          .map((t, i) => model.createTemplate({
            title: String(t.title || "Untitled"),
            body: sanitize.sanitize(String(t.body || ""), { images: canImages() }),
            shortcut: String(t.shortcut || ""),
            tags: Array.isArray(t.tags) ? t.tags : [],
            favorite: !!t.favorite,
            sortIndex: base + i
          }, base + i));
        if (!recs.length) throw new Error("nothing to import");
        const added = await store.bulkInsert(recs);
        render();
        if (added.length < recs.length) {
          alert("Imported " + added.length + " of " + recs.length + " — the rest hit the "
            + store.templateLimit() + "-template free-plan limit.");
        } else {
          alert("Imported " + added.length + " template(s).");
        }
      } catch (err) {
        console.error("[CR] import failed", err);
        alert("Import failed — that doesn't look like a valid Canned Responses JSON file.");
      } finally {
        e.target.value = "";
      }
    };
    reader.readAsText(file);
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
